﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace assignment.Models
{
    public class GuestResponse
    {
        [Required(ErrorMessage = "Please enter your name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter your Email")]
        // enter correct email

        [RegularExpression(".+\\@.+\\..+", ErrorMessage = ("Please enter a valid email address"))]
        public string Email { get; set; }
        [Required(ErrorMessage = "Please enter your Phone")]
        public string Phone { get; set; }
        [Required(ErrorMessage = "So you do not know that have you seem NBA?")]

        public bool? KnownNBA { get; set; }
        /*
        internal void Add(GuestResponse response)
        {
            throw new NotImplementedException();
        }
        */


    }
}
