﻿using System;
using Microsoft.AspNetCore.Mvc;
using assignment.Models;
using System.Linq;
namespace assignment.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()

        {
            int hour = DateTime.Now.Hour;
            // Termary statement
            ViewBag.Greeting = hour < 12 ? "Good Moring " : "Good Afternoon";
            return View("Myview");
        }


        [HttpGet]
        public ViewResult Introduction()
        {
            return View();
        }


        [HttpPost]
        public ViewResult Introduction(GuestResponse guestResponse)
        {
            if (ModelState.IsValid)
            {
                Repository.AddResponse(guestResponse);
                return View("JOINIF", guestResponse);
            }
            else
            {
                return View();
            }

        }
        public ViewResult JOINIF(GuestResponse guestResponse)
        {
            if (ModelState.IsValid)
            {
                Repository.AddResponse(guestResponse);
                return View("INF", guestResponse);
            }
            else
            {
                return View();
            }

        }


     
    }
}
